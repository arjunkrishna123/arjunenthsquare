var Data = [
    {
        "category_product": "kitchen",
        "product_name": "4-Piece Set Bamboo Table Matt"
    },
    {
        "category_product": "kitchen",
        "product_name": "Expresso Coffee Maker"
    },
    {
        "category_product": "shoes",
        "product_name": "Puma Trainers x3"
    },
    {
        "category_product": "home",
        "product_name": "4x6 Photo Frame"
    },
    {
        "category_product": "shoes",
        "product_name": "Skechers ProWalkers"
    },
    {
        "category_product": "home",
        "product_name": "Shower Curtain"
    },
    {
        "category_product": "home",
        "product_name": "Accent Table Lamp"
    },
    {
        "category_product": "electronics",
        "product_name": "Cannon x930 DSLR Camera"
    },
    {
        "category_product": "kitchen",
        "product_name": "12 Qt Pressure Cooker"
    },
    {
        "category_product": "electronics",
        "product_name": "Apple Iphone 8"
    },
    {
        "category_product": "kitchen",
        "product_name": "Wooden Hexagonal Coasters"
    },
    {
        "category_product": "electronics",
        "product_name": "Bose QC 300 Headphones"
    },
    {
        "category_product": "shoes",
        "product_name": "Reebok Classic 1990"
    },
    {
        "category_product": "kitchen",
        "product_name": "12-Piece Knife Set"
    },
    {
        "category_product": "shoes",
        "product_name": "Nike Air Max Elite"
    },
    {
        "category_product": "home",
        "product_name": "100% Cotton Towels"
    },
    {
        "category_product": "electronics",
        "product_name": "Sony Super Bass Earbuds"
    },
    {
        "category_product": "shoes",
        "product_name": "Addidas Foamfits"
	
    }
];

function populateProductCategoryList() {


    console.log('data---', Data);

    var productCategoryList = {};

    Data.forEach((product) => {
        if (productCategoryList.hasOwnProperty(product.category_product)) {
            productCategoryList[product.category_product].push(product);
        } else {
            productCategoryList[product.category_product] = [product];
        }
    });
    console.log(productCategoryList);
    var categoryList = '';
    Object.keys(productCategoryList).forEach((category) => {
        categoryList += `<li class="categoryListItems" item-type="${category}">${category}</li>`
    });
    document.getElementById("category_list1").innerHTML = categoryList;

    console.log(document.getElementsByClassName('categoryListItems'));
    var categoryListItems = document.getElementsByClassName('categoryListItems');
    for (var i = 0; i < categoryListItems.length; i++) {
        console.log(categoryListItems[i])
        categoryListItems[i].addEventListener('click', (evt) => {
            console.log('asdasd', evt.target.getAttribute('item-type'));
            populateProductListItem(productCategoryList[evt.target.getAttribute('item-type')]);
        })
    }


}



function populateProductListItem(currentProductItems) {
    var productList = '';
    currentProductItems.forEach((pList) => {
        productList += `<li>${pList.product_name}</li>`
    });
    document.getElementById("product_list2").innerHTML = productList;
}

window.onload = function () {
    populateProductCategoryList();
}
